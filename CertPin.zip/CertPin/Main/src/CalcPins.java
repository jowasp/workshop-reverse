/**
 * Created by johannacuriel on 3/7/17.
 */
import javax.net.ssl.*;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

public class CalcPins {

    private MessageDigest digest;

    public CalcPins() throws Exception {

        digest = MessageDigest.getInstance("SHA1");
    }

    public static void main(String[] args) {
        if ((args.length == 1) || (args.length == 2)) {

            String[] hostAndPort = args[0].split(":");
            String host = hostAndPort[0];
            //if port blank assume 443
            int port = (hostAndPort.length == 1) ? 443 : Integer.parseInt(hostAndPort[1]);

            try {

                CalcPins calc = new CalcPins();
                calc.fetchAndPrintPinHashs(host, port);


            } catch (Exception e) {

                e.printStackTrace();
            }

        } else {
            System.out.println("Usage: java Calcpins <host>[:port]");
            return;
        }
    }

    private void fetchAndPrintPinHashs(String host, int port) throws Exception {
        SSLContext context = SSLContext.getInstance("TLS");
        PublicKeyExtractingTrustManager tm = new PublicKeyExtractingTrustManager();
        context.init(null, new TrustManager[]{tm}, null);
        SSLSocketFactory factory = context.getSocketFactory();
        SSLSocket socket = (SSLSocket) factory.createSocket(host, port);
        socket.setSoTimeout(20000);
        socket.startHandshake();
        socket.close();
    }

    public class PublicKeyExtractingTrustManager implements X509TrustManager {

        public X509Certificate[] getAcceptedIssuers() {
            //chnage piece of code to avoid exception error
            //throw new UnsupportedOperationException();
            return new X509Certificate[0];
        }

        public void checkClientTrusted(X509Certificate[] chain, String authType)
                throws CertificateException {
            throw new UnsupportedOperationException();

        }

        public void checkServerTrusted(X509Certificate[] chain, String authType)
                throws CertificateException {
            for (X509Certificate cert : chain) {
                byte[] pubKey = cert.getPublicKey().getEncoded();
                final byte[] hash = digest.digest(pubKey);
                System.out.println(bytesToHex(hash));
            }

        }

    }

    //implement TrusManager to validate the keys

    public class PubKeyPinningTrustmanager implements X509TrustManager {

        private final String[] mPins;
        private final MessageDigest mDigest;

        public PubKeyPinningTrustmanager(String[] pins)
                throws GeneralSecurityException {
            this.mPins = pins;
            mDigest = MessageDigest.getInstance("SHA1");
        }

        @Override
        public void checkServerTrusted(X509Certificate[] chain, String authType)
                throws CertificateException {
            //validate pins
            for (X509Certificate cert : chain) {
                final boolean expected = validateCertificatePin(cert);
                if (!expected) {
                    throw new CertificateException("No valid pin found");

                }
            }
        }

        @Override
        public void checkClientTrusted(X509Certificate[] chain, String authType)
                throws CertificateException {
            throw new CertificateException("Client validation not implemented");
        }

        @Override
        public X509Certificate[] getAcceptedIssuers() {
            return null;
        }
        private boolean validateCertificatePin(X509Certificate certificate)
                throws CertificateException{
            final byte[] pubKeyInfo = certificate.getPublicKey().getEncoded();
            final byte[] pin = mDigest.digest(pubKeyInfo);
            final String pinAsHex = bytesToHex(pin);
            for (String validPin : mPins){
                if(validPin.equalsIgnoreCase(pinAsHex)){
                    return true;
                }
            }
            return false;

        }
    }

    public static String bytesToHex(byte[] bytes) {
        final char[] hexArray = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
        char[] hexChars = new char[bytes.length * 2];
        int v;
        for (int j = 0; j < bytes.length; j++) {
            v = bytes[j] & 0xFF;
            hexChars[j * 2] = hexArray[v >>> 4];
            hexChars[j * 2 + 1] = hexArray[v & 0x0F];
        }
        return new String(hexChars);
    }

    private static String[] pins = new String[]{
            "A80DD75ED554DFFF34C7C7D3B5E96A6343D52F99",
            "43DAD630EE53F8A980CA6EFD85F46AA37990E0EA",
            "C07A98688D89FBAB05640C117DAA7D65B8CACC4E"};

    /*TrustManager[] trustManagers = new TrustManager[] { new PubKeyPinningTrustmanager(pins)};
    SSLContext sslContext = SSLContext.getInstance("TLS");
    sslContext.init(null, trustManagers, null);
    HttpsURLConnection urlConnection = (HttpsURLConnection)url.openConnection();
    urlConnection.setSSLSocketFactory(sslContext.getSocketFactory());
    urlConnection.connect();*/

}









